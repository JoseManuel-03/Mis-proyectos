package ceu.dam.examen.model;

public class Asignatura {
	
	private String codigo; // no puede ser blanco
	private String nombre; // no puede ser blanco
	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	
}
