# ChangePasswordRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Object** |  |  [optional]
**passwordOld** | **Object** |  |  [optional]
**passwordNew** | **Object** |  |  [optional]
