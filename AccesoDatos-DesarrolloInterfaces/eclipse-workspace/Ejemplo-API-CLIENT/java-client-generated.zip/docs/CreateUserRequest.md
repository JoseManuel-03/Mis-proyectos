# CreateUserRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **Object** |  |  [optional]
**password** | **Object** |  |  [optional]
**email** | **Object** |  |  [optional]
