# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Object** |  |  [optional]
**username** | **Object** |  |  [optional]
**password** | **Object** |  |  [optional]
**email** | **Object** |  |  [optional]
**createdDate** | **Object** |  |  [optional]
**lastLoginDate** | **Object** |  |  [optional]
